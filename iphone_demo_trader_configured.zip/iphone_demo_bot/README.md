# iPhone 1-minute paper-trading dashboard

Independent simulated trades, not Quotex orders. Real-market candles require a Twelve Data API key and a plan that supports 1-minute forex data.

## Run locally
```
pip install -r requirements.txt
streamlit run app.py
```

## iPhone hosting
1. Create a private GitHub repository and upload `app.py` and `requirements.txt`.
2. Deploy `app.py` using Streamlit Community Cloud (share.streamlit.io).
3. Open the HTTPS dashboard URL in iPhone Safari.
4. Enter your Twelve Data API key in the sidebar, select a symbol and choose Start demo.
5. Use Emergency stop to prevent new entries. Reset session clears simulated trades.

## Limitations
- No Quotex login, OTC feed or broker orders.
- Trades are virtual and session state can reset if server restarts.
- Trades close at first observed quote after 60 seconds, not guaranteed exactly 60 seconds.
- Twelve Data timestamps may be exchange-local; latest candle is excluded conservatively.
- Refresh every 15 seconds can exceed free API quotas.
- Streamlit Community Cloud can sleep and is not suitable for unattended 24/7 execution.
- For accurate settlement use a persistent server, timestamp-normalized tick feed and durable trade database.
